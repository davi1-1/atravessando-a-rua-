var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["d0f79ec6-99f0-4e17-9a69-b8e85d068e3b","7e7de345-9178-465d-8905-057ee975a9ae","f2e15c1d-c761-44ad-bc7e-2c7d11952f26","ea005838-76ea-45fb-b4f2-3e9b0558b84a","d8350423-7578-4ab0-9112-532ba8f95433","bf2c7f7e-cf1a-4836-b69d-97edf3668d34","cc90a874-1567-4092-895a-5aa2970ce44e"],"propsByKey":{"d0f79ec6-99f0-4e17-9a69-b8e85d068e3b":{"name":"galinha","sourceUrl":null,"frameSize":{"x":400,"y":400},"frameCount":1,"looping":true,"frameDelay":12,"version":"NjjZbLjrZmDMVqOBWtQ3zWGO53pnk47M","categories":["vehicles"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":400},"rootRelativePath":"assets/d0f79ec6-99f0-4e17-9a69-b8e85d068e3b.png"},"7e7de345-9178-465d-8905-057ee975a9ae":{"name":"car_red_1","sourceUrl":"assets/api/v1/animation-library/gamelab/PgZ9LG37ZQqVk5aChd38vWQARDnCdCKu/category_vehicles/car_red.png","frameSize":{"x":71,"y":131},"frameCount":1,"looping":true,"frameDelay":2,"version":"PgZ9LG37ZQqVk5aChd38vWQARDnCdCKu","categories":["vehicles"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":71,"y":131},"rootRelativePath":"assets/api/v1/animation-library/gamelab/PgZ9LG37ZQqVk5aChd38vWQARDnCdCKu/category_vehicles/car_red.png"},"f2e15c1d-c761-44ad-bc7e-2c7d11952f26":{"name":"motorcycle_1","sourceUrl":"assets/api/v1/animation-library/gamelab/qK9AmfhKuafr7c1U_QozyIijRUAkXTZz/category_vehicles/motorcycle.png","frameSize":{"x":71,"y":131},"frameCount":1,"looping":true,"frameDelay":2,"version":"qK9AmfhKuafr7c1U_QozyIijRUAkXTZz","categories":["vehicles"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":71,"y":131},"rootRelativePath":"assets/api/v1/animation-library/gamelab/qK9AmfhKuafr7c1U_QozyIijRUAkXTZz/category_vehicles/motorcycle.png"},"ea005838-76ea-45fb-b4f2-3e9b0558b84a":{"name":"car_yellow_1","sourceUrl":"assets/api/v1/animation-library/gamelab/T3gaSeDCsA_YHvy7GieJSRtG4e1P8Ac1/category_vehicles/car_yellow.png","frameSize":{"x":71,"y":131},"frameCount":1,"looping":true,"frameDelay":2,"version":"T3gaSeDCsA_YHvy7GieJSRtG4e1P8Ac1","categories":["vehicles"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":71,"y":131},"rootRelativePath":"assets/api/v1/animation-library/gamelab/T3gaSeDCsA_YHvy7GieJSRtG4e1P8Ac1/category_vehicles/car_yellow.png"},"d8350423-7578-4ab0-9112-532ba8f95433":{"name":"car_black_1","sourceUrl":"assets/api/v1/animation-library/gamelab/CSqSIJEb65ONvhatlX8ENonwX._VZQ_n/category_vehicles/car_black.png","frameSize":{"x":71,"y":131},"frameCount":1,"looping":true,"frameDelay":2,"version":"CSqSIJEb65ONvhatlX8ENonwX._VZQ_n","categories":["vehicles"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":71,"y":131},"rootRelativePath":"assets/api/v1/animation-library/gamelab/CSqSIJEb65ONvhatlX8ENonwX._VZQ_n/category_vehicles/car_black.png"},"bf2c7f7e-cf1a-4836-b69d-97edf3668d34":{"name":"corgi_1","sourceUrl":"assets/api/v1/animation-library/gamelab/ThFwZTeCRzx1pD6mg0VhDboKPBXixvrN/category_animals/corgi.png","frameSize":{"x":542,"y":500},"frameCount":1,"looping":true,"frameDelay":2,"version":"ThFwZTeCRzx1pD6mg0VhDboKPBXixvrN","categories":["animals"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":542,"y":500},"rootRelativePath":"assets/api/v1/animation-library/gamelab/ThFwZTeCRzx1pD6mg0VhDboKPBXixvrN/category_animals/corgi.png"},"cc90a874-1567-4092-895a-5aa2970ce44e":{"name":"kid_44_suit_1","sourceUrl":"assets/api/v1/animation-library/gamelab/bO2W0UdDHgyjblRjzA8l8ScOzuEiQrBl/category_people/kid_44_suit.png","frameSize":{"x":152,"y":300},"frameCount":1,"looping":true,"frameDelay":2,"version":"bO2W0UdDHgyjblRjzA8l8ScOzuEiQrBl","categories":["people"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":152,"y":300},"rootRelativePath":"assets/api/v1/animation-library/gamelab/bO2W0UdDHgyjblRjzA8l8ScOzuEiQrBl/category_people/kid_44_suit.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

var life = 0;
var car1, car2, car3,car4;
var boundary1, boundary2;
var sam;

  boundary1 = createSprite(190,120,420,3);
  boundary2 = createSprite(190,260,420,3);
  
  sam = createSprite(30,190,13,13);
  sam.shapeColor = "green";
  sam.setAnimation("kid_44_suit_1");
  sam.scale= 0.1;
  
  car1 = createSprite(100,130,10,10);
  car1.shapeColor = "red";
  car2 = createSprite(215,130,10,10);
  car2.shapeColor = "red";
  car3 = createSprite(165,250,10,10);
  car3.shapeColor = "red";
  car4 = createSprite(270,250,10,10);
  car4.shapeColor = "red";
  
  
  car1.velocityY="8";
  car2.velocityY="8";
  car3.velocityY="8";
  car4.velocityY="8";
  
  car1.setAnimation("car_black_1");
  car1.scale= 0.2;
  car2.setAnimation("car_red_1");
  car2.scale= 0.2;
  car3.setAnimation("motorcycle_1");
  car3.scale= 0.2;
  car4.setAnimation("car_yellow_1");
  car4.scale= 0.2;
  
  var otica = createSprite(380,190, 70,136);
  otica.shapeColor="yellow";
 
 
//adicione velocidade para fazer o carro se mover.

function draw() {
   background("white");
  text("mortes: " + life,200,100);
  strokeWeight(0);
  fill("lightblue");
  rect(0,120,52,140);
  rect(345,120,52,140);
  
  
  
  
// crie a função rebater, para fazer o carro rebater nos limites

   createEdgeSprites();

  car1.bounceOff(boundary1);
  car2.bounceOff(boundary1);
  car3.bounceOff(boundary1);
  car4.bounceOff(boundary1);
  car1.bounceOff(boundary2);
  car2.bounceOff(boundary2);
  car3.bounceOff(boundary2);
  car4.bounceOff(boundary2);
  sam.bounce(leftEdge);
  sam.bounce(rightEdge);








//Adicione a condição para fazer Sam se mover para a esquerda e para a direita

 if (keyDown("LEFT_ARROW")) {
     sam.x=sam.x-5;
 }
 
 if (keyDown("RIGHT_ARROW")) {
     sam.x=sam.x+5;
 }
 
 
 
//Adicione a condição para reduzir a vida de Sam quando ele encostar no carro.

 if (sam.isTouching(car1)) {
   sam.x=30;
   sam.y=190;
   life=life+1;
}
if (sam.isTouching(car2)) {
   sam.x=30;
   sam.y=190;
   life=life+1;
}
if (sam.isTouching(car3)) {
   sam.x=30;
   sam.y=190;
   life=life+1;
}
if (sam.isTouching(car4)) {
   sam.x=30;
   sam.y=190;
   life=life+1;
}
if (sam.isTouching(otica)) {
  car1.velocityY="0";
  car2.velocityY="0";
  car3.velocityY="0";
  car4.velocityY="0";
  text("Você venceu!!!",170,160);
  textSize(12);
  textFont(200);
  fill("red");
  sam.velocityX="0";
}



  
 drawSprites();
}

// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
